import java.util.Scanner;
public class Kwartaal3 {
	public static void main (String[] args) {
	System.out.println("Geef een maand in (1-12) : ");
	Scanner scan = new Scanner(System.in);
	int maand = scan.nextInt();
	int kwartaal = maand / 3;
	System.out.println(kwartaal == 0 ? "Eerste kwartaal" : kwartaal == 1 ? "Tweede kwartaal" : kwartaal == 2 ? "Derde kwartaal " : kwartaal == 3 ? "Vierde kwartaal " : "dit is een ongeldige maand");
	}
}