/**
* FahrenheitNaarCelsius d.m.v scanner
* @author Matthias Vantomme
* @version September 2015
*/
import java.util.Scanner;
public class KleinsteGetal {
	public static void main (String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Geef het eerste getal in : " );
		int getal1 = s.nextInt();
		System.out.println("Geef het tweede getal in : " );
		int getal2 = s.nextInt();
		int kleinstegetal = Math.min(getal1,getal2);
		System.out.println("Het kleinstegetal is : " + kleinstegetal) ;
	}
}
