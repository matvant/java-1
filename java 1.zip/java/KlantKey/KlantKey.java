/**
*  KlantKey d.m.v scanner
* // we gaan ervan uit da je jouw naam schrijft met hoofdletter.
* //  zoniet zouden we numeriekewaarde3 nog is -32 moeten doen.
* @author Matthias Vantomme
* @version September 2015
*/
import java.util.Scanner;
public class KlantKey {
	public static void main (String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Geef je voornaam + achternaam : " );
		String naam = s.nextLine();
		String derdeLetter = naam.substring(2).toUpperCase();
		String hoofdLetterDerdeLetter = naam.substring(2);
		char karakter = hoofdLetterDerdeLetter.charAt(0);
		int numeriekeWaarde = (int) karakter;
		int getal = (numeriekeWaarde + 5) - 32;
		char karakter2 = (char) getal;
		char laatsteLetter = naam.charAt(naam.length() - 1);
		int numeriekeWaarde2 = (int) laatsteLetter;
		int getal2 = (numeriekeWaarde2 - 32);
		char laatsteLetterInHoofdLettters = (char) getal2;
		String eersteLetter = naam.substring(0).toUpperCase();
		String hoofdLetterEersteLetter = naam.substring(0);
		char karakter3 = hoofdLetterEersteLetter.charAt(0);
		int numeriekeWaarde3 = (int) karakter3;
		int produkt = numeriekeWaarde3 * numeriekeWaarde3;
		System.out.println("ODISEE" + karakter2 + laatsteLetterInHoofdLettters + produkt) ;
	}
}