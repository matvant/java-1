/**
* Dobbelsteen d.m.v scanner
* @author Matthias Vantomme
* @version november 2016
*/
import java.util.Scanner;
public class Dobbelsteen {
	public static void main (String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Hoeveel ogen wil je werpen? ");
		int werpen = s.nextInt();
		int cijfer = 0;
		int getal = 0;
		while (getal!=werpen){
			getal = (int) (Math.random()* 6) +1;
			cijfer++;
			System.out.println("Poging "+cijfer+" : "+getal);
		}
		System.out.println("In " + cijfer + " pogingen werd een " + getal + " gedobbeld");
	}
}