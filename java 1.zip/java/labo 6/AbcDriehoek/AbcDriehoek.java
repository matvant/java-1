/**
* AbcDriehoek d.m.v scanner
* @author Matthias Vantomme
* @version november 2015
*/
import java.util.Scanner;
public class AbcDriehoek {
	public static void main (String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("geef een waarde in");
		int waarde = s.nextInt();
		char letter = 'a' ;
		for (int regel = waarde; regel > 0; regel--) {
			for (int ster = 1; ster < regel; ster++){
				System.out.print(".");
			}
			for(int i = waarde; i>=regel;i--){
				System.out.print(letter);
			}
			System.out.println("");
			letter++;
		}
	}
}