/**
* conversies
* datum afprinten
* @author Matthias Vantomme
* @version September 2015
*/
public class Conversies {
	public static void main (String[] args) {
		short getal = 69 ;
		int getalInt = (int) getal ;
		long getalLong = (long) getal ;
		float getalFloat = (float) getal ;
		double getalDouble = (double) getal ;
		System.out.println("short : " + getal) ;
		System.out.println("int : " + getalInt) ;
		System.out.println("long : " + getalLong) ;
		System.out.println("float : " + getalFloat) ;
		System.out.println("double : " + getalDouble) ;
  	}
}