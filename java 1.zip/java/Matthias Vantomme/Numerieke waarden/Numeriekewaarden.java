/**
* numerieke waarde afprinten met char + int
* datum afprinten
* @author Matthias Vantomme
* @version September 2015
*/
public class Numeriekewaarden {
	public static void main (String[] args) {
		char karakter = '@' ;
		int numeriekeWaarde = (int) karakter ;
		System.out.println("dit is het karakter : " + karakter ) ; 
		System.out.println("de numerieke waarde ervan is : " + numeriekeWaarde) ;
	}
}