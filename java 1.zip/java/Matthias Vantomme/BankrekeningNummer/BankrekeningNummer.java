/**
* Bankrekeningnummer d.m.v. scanner
* @author Matthias Vantomme
* @version september 2015
*/
import java.util.Scanner;
public class BankrekeningNummer{
public static void main (String[]args){
	Scanner s = new Scanner(System.in);
	System.out.println("Geef je rekeningnummer met IBAN code");
	String iban = s.next();
	String code = s.next();
	String rekeningNummer = s.next()+" "+s.next()+" "+s.next();
	System.out.println("De IBAN code is : " + code);
	System.out.println("Het rekeningnummer : " + rekeningNummer);
	}
}