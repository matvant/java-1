/**
* datum afprinten
* @author Matthias Vantomme
* @version September 2015
*/
public class Gemiddelde {
	public static void main (String[] args) {
		int var1 = 7 ;
		int var2 = 3 ;
		int var3 = 6 ;
		int var4 = 2 ;
	    int gemiddelde = ((var1 + var2 + var3 + var4 )/4) ;
		int rest = (var1 + var2 + var3 + var4)%4 ;
		double getal = (var1 + var2 + var3 + var4) ;
		double gemiddeld = (getal/4) ;
		System.out.println("De waarden van je variabelen zijn : " + var1 + "," + var2 + "," + var3 + " en " + var4 ) ;
		System.out.println("Het gehele gemiddelde is : " + gemiddelde) ; 
		System.out.println("De gehele rest is : " + rest) ;
		System.out.println("Het gemiddelde is : " + gemiddeld) ; 
    }
}