/**
* numerieke waarden met scanner
* datum afprinten
* @author Matthias Vantomme
* @version September 2015
*/
import java.util.Scanner;
public class NumeriekeWaarden2 {
	public static void main (String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("dit is het karakter : " ) ;
		char karakter = s.next().charAt(0) ;
		int numeriekeWaarde = (int) karakter ;
		System.out.println("de numerieke waarde ervan is : " + numeriekeWaarde) ;
	}
}