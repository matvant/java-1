/**
* Permutatie d.m.v. scanner
* @author Matthias Vantomme
* @version September 2015
*/
import java.util.Scanner;
public class Permutatie {
	public static void main (String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Geef 3 double getallen :  " ) ;
		double variabeleA = s.nextDouble();
		double variabeleB = s.nextDouble();
		double variabeleC = s.nextDouble();
		double variabeleANapermutatie = variabeleB;
		double variabeleBNapermutatie = variabeleC;
		double variabeleCNapermutatie = variabeleA;

		System.out.println("variabeleA is : " + variabeleA ) ;
		System.out.println("variabeleB is : " + variabeleB ) ;
		System.out.println("variabeleC is : " + variabeleC ) ;
		System.out.println("Na Permutatie " ) ;
		System.out.println("variabeleA is : " + variabeleANapermutatie ) ;
		System.out.println("variabeleB is : " + variabeleBNapermutatie ) ;
		System.out.println("variabeleC is : " + variabeleCNapermutatie ) ;
	}
}