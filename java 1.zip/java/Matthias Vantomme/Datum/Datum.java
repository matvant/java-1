/**
* datum afprinten
* @author Matthias Vantomme
* @version September 2015
*/
public class Datum {
	public static void main (String[] args) {
	int dag = 7 ;
	int maand = 7 ;
	int jaar = 2015 ;
	System.out.println("de opgegeven datum is : " + dag + "-" + maand + "-" + jaar) ;
	}
}