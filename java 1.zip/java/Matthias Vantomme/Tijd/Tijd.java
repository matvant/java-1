/**
* Tijd d.m.v. scanner
* @author Matthias Vantomme
* @version september 2015
*/
import java.util.Scanner;
public class Tijd {
public static void main (String[]args){
	Scanner s = new Scanner(System.in);
	System.out.println("Geef je input ( uur : minuten : seconden) : ");
	Byte uur = s.nextByte();
	char dubbelePunt = s.next().charAt(0) ;
	Byte minuten = s.nextByte();
	char dubbelePunt2 = s.next().charAt(0) ;
	Byte seconden = s.nextByte();	
	System.out.println("Het ingegeven uur was : " + uur + " " + "u" + " " + dubbelePunt + " " + minuten + " " + "min" + " " + dubbelePunt2 + " " + seconden + " " + "sec");
	}
}