/**
* echo d.m.v. scanner
* @author Matthias Vantomme
* @version September 2015
*/
import java.util.Scanner;
public class Echo {
	public static void main (String[] args) {
		Scanner s = new Scanner(System.in);
		String zin = s.nextLine();
		System.out.println(zin) ;
	}
}