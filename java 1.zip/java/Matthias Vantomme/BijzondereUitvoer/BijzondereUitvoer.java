/**
* Bijzondere uitvoer met \n als nieuwelijn starten en \"  \'  \\"
* @author Matthias Vantomme
* @version September 2015
*/
public class BijzondereUitvoer {
	public static void main (String[] args) {
		System.out.println("Deze tekst staat \"tussen dubbele quotes\", \ndeze \'tussen enkele quotes\' \nen die \\tussen back slashes\\" ) ;
    }
}