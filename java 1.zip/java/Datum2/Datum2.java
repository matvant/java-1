/**
* datum afprinten
* @author Matthias Vantomme
* @version September 2015
*/
import java.util.Scanner;
public class Datum2 {
	public static void main (String[] args) {
	Scanner s = new Scanner(System.in);
	System.out.println("Geef de dag in : " );
	int dag = s.nextInt() ;
	System.out.println("Geef de maand in : " );
	int maand = s.nextInt() ;
	System.out.println("Geef het jaar in : " );
	int jaar = s.nextInt() ;
	System.out.println( " de opgegeven datum is : "  + ((dag <= 9) ? "0" : "") + dag  +  "-" + ((maand <= 9) ? "0" : "") + maand + "-" + jaar) ;
	}
}