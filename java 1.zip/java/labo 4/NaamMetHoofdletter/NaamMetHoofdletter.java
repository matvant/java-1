/**
* NaamMetHoofdletter d.m.v scanner
* @author Matthias Vantomme
* @version September 2015
*/
import java.util.Scanner;
public class NaamMetHoofdletter {
	public static void main (String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Geef ja naam in kleine letters : " );
		String naam = s.nextLine();
		String naam2 = naam.substring(0,1).toUpperCase();
		String naam3 = naam.substring(1);
		System.out.println("Uw  voornaam is : " + naam2 + naam3) ;
	}
}