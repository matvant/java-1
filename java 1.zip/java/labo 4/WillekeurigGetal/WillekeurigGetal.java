/**
* willekeurigGetal met Math
* @author Matthias Vantomme
* @version September 2015
*/
public class WillekeurigGetal {
	public static void main (String[] args) {
		double willekeurigGetal = (int) (Math.random() * 100 + 50);
		System.out.println("Het willekeurigGetal is : " + willekeurigGetal) ;
	}
}
