/**
* ButSecond d.m.v scanner
* @author Matthias Vantomme
* @version September 2015
*/
import java.util.Scanner;
public class ButSecond {
	public static void main (String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Geef je zin : " );
		String zin = s.nextLine();
		int zin1 = zin.indexOf(" ");
		String eersteWoord = zin.substring(0,zin1);
		String restZin = zin.substring(zin1 + 1);
		int zin2 = restZin.indexOf(" ");
		String restZin2 = restZin.substring(zin2);
		System.out.println("--> : " + eersteWoord + restZin2) ;
	}
}