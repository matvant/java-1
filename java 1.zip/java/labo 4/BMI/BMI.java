/**
* BMI d.m.v scanner
* @author Matthias Vantomme
* @version September 2015
*/
import java.util.Scanner;
public class BMI {
	public static void main (String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Geef het gewicht in kg : " );
		double gewicht = s.nextInt();
		System.out.println("Geef de lengte in meter : " );
		double lengte = s.nextInt();
		double bmi = gewicht / Math.pow(lengte,2);
		System.out.println("BMI is : " + bmi) ;
	}
}