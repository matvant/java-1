/**
* WetNotatie d.m.v scanner
* @author Matthias Vantomme
* @version September 2015
*/
import java.util.Scanner;
public class WetNotatie {
	public static void main (String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Geef het grondtal in : " );
		double grondtal = s.nextDouble();
		System.out.println("Geef een macht in : " );
		double macht = s.nextDouble();
		double getal = Math.pow(10,macht);
		double geta2 = grondtal*getal;
		System.out.println("de uitkomst is : " + geta2) ;
	}
}