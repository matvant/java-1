/**
* ButFirst d.m.v scanner
* @author Matthias Vantomme
* @version September 2015
*/
import java.util.Scanner;
public class ButFirst {
	public static void main (String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Geef je zin : " );
		String zin = s.nextLine();
		int zin1 = zin.indexOf(" ");
		String zin2 = zin.substring(zin1);
		System.out.println("--> : " + zin2) ;
	}
}