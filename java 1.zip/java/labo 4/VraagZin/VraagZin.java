/**
* VraagZin d.m.v scanner
* @author Matthias Vantomme
* @version September 2015
*/
import java.util.Scanner;
public class VraagZin {
	public static void main (String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Geef je zin : " );
		String zin = s.nextLine();
		int eersteSpatie = zin.indexOf(" ");
		String eersteWoord = zin.substring(0,eersteSpatie);
		String eersteWoord1 = eersteWoord.substring(0,1).toLowerCase();
		String eersteWoord2 = eersteWoord.substring(1);
		String restZin = zin.substring(eersteSpatie + 1);
		int tweedeSpatie = restZin.indexOf(" ");
		String tweedeWoord = restZin.substring(0,tweedeSpatie);
		String tweedeWoord2 = tweedeWoord.substring(0,1).toUpperCase();
		String tweedeWoord3 = tweedeWoord.substring(1);
		String restzin2 = restZin.substring(tweedeSpatie + 1);
		System.out.println("--> : " + tweedeWoord2 + tweedeWoord3 + " " + eersteWoord1 + eersteWoord2 + " " + restzin2 +  " ? ") ;

	}
}