/**
*  EindCijfer d.m.v scanner
* @author Matthias Vantomme
* @version September 2015
*/
import java.util.Scanner;
public class EindCijfer {
	public static void main (String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Geef het theorie-examen resultaat : " );
		double theorieExamen = s.nextDouble();
		System.out.println("Geef het practicum resultaat : " );
		double practicum = s.nextDouble();
		double gemiddelde = ((practicum + theorieExamen)/2);
		if (practicum < theorieExamen) System.out.println(" hierbij telt uw practicum resultaat : " + practicum);
		else System.out.println("het gemiddelde is : " + gemiddelde);	
	}
}