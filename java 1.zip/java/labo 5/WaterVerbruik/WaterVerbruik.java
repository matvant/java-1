/**
*  WaterVerbruik d.m.v scanner
* @author Matthias Vantomme
* @version September 2015
*/
import java.util.Scanner;
public class WaterVerbruik {
	public static void main (String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Welk tarief wil je? (Tarief 1 = 75 euro / tarief 2 = 50 euro: " );
		int factor = 0;
		int tarief = 0;
		int keuzeTarief = s.nextInt();
		switch(keuzeTarief) {
			case 1: 
				tarief = 75;
				factor = 1;
				break;
			case 2: 
				tarief = 50;
				factor = 2;
				break;
			default: System.out.println("kies een getal 1 of 2");
			break;
		}
		System.out.println(" hoeveel is jouw verbruik  : ");
		double verbruikt = s.nextDouble();
		double prijs = (tarief + factor*verbruikt)*1.06;
		System.out.println(" Het verbruik is : " + prijs);
	}
}