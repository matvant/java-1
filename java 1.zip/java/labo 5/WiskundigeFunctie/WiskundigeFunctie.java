/**
*  WiskundigeFucntie d.m.v scanner
* @author Matthias Vantomme
* @version September 2015
*/
import java.util.Scanner;
public class WiskundigeFunctie {
	public static void main (String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Geef x in : " );
		double x = s.nextDouble();
		System.out.println("Geef y in : ");
		double y = s.nextDouble();
		if (x>=0 && y>= 0) System.out.println(+x + y);
		else if (x>=0 && y< 0) System.out.println(+x + (y*y));
		else if (x<0 && y>=0) System.out.println((+x*x) + y);
		else if (x<0 && y<0 ) System.out.println((+x*x) + (y*y));
	}
}