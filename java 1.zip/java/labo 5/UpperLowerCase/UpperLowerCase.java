/**
*  // UpperLowerCase d.m.v scanner
* @author Matthias Vantomme
* @version September 2015
*/
import java.util.Scanner;
public class UpperLowerCase {
	public static void main (String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Geef een woord in : " );
		String woord = s.nextLine();
		int volledigWoord = woord.length() ;
		String alsEven = woord.toUpperCase();
		String alsOneven = woord.toLowerCase();
		if ((volledigWoord/2)*2 == volledigWoord ) System.out.println("even = " + alsEven);
		else System.out.println("oneven = " + alsOneven);	
	}
}