/**
*  AantalDagen d.m.v scanner
* @author Matthias Vantomme
* @version September 2015
*/
import java.util.Scanner;
public class AantalDagen {
	public static void main (String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Kies het nummer van de maand in: " );
		int getal = 0;
		int maand = s.nextInt();
		switch(maand) {
			case 1: 
			case 3:
			case 5:
			case 7:
			case 8:
			case 10:
			case 12:
				System.out.println("de maand heeft 31 dagen ");
				break;
			case 4:
			case 6: 
			case 9:
			case 11:
				System.out.println(" de maand heeft 30 dagen");
				break;
			case 2:
				System.out.println("is het een schrikkeljaar? ");
				String maand2 = s.nextLine();
				break;

			default: System.out.println("geef een getal tussen 1 en 12");
			break;
		}
	}
}