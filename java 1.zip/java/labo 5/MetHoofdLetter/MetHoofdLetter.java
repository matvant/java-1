/**
*  MetHoofdLetter d.m.v scanner
* @author Matthias Vantomme
* @version September 2015
*/
import java.util.Scanner;
public class MetHoofdLetter {
	public static void main (String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Geef een woord in : " );
		String woord = s.nextLine();
		char eersteLetter = woord.charAt(0);
		int getal = (int) eersteLetter;
		if (getal >65 && getal < 91 ) System.out.println("Hoofdletter");
		if (getal >96 && getal <123 ) System.out.println("KleineLetter");
		if (getal >47 && getal < 58 ) System.out.println("Cijfer");
		
	}
}