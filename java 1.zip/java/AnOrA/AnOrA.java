/**
*  AnOrA d.m.v scanner
* @author Matthias Vantomme
* @version September 2015
*/
import java.util.Scanner;
public class AnOrA {
	public static void main (String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Geef een engels woord in : " );
		String woord = s.nextLine();
		char eersteLetter = woord.charAt(0);
		int getal = (int) eersteLetter;
		if (getal == 97 || getal == 101 || getal == 105 || getal == 111 || getal == 117 || getal == 121 ) System.out.println("Dit wordt : an " + woord);
		else System.out.println("Dit wordt : a " + woord);
	}
}