/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Matrix;

/**
 *
 * @author matthias.vantomme
 */
import java.util.Scanner;

public class MatrixDemo {

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("geef de rijen en kolommen in ");
        int rijen1 = s.nextInt();
        int kolommen1 = s.nextInt();
        Matrix Matrix1 = new Matrix(rijen1, kolommen1);

        System.out.println("geef de getallen in ");

        int[][] a1 = new int[rijen1][kolommen1];

        for (int rij = 0; rij < rijen1; rij++) {
            for (int kol = 0; kol < kolommen1; kol++) {
                Matrix1.matrix[rij][kol] = s.nextInt();

            }
        }

        Matrix1.afprinten();
        int[] som = Matrix1.rijSommen();
        int[] som1 = Matrix1.kolomSommen();
        for (int i = 0; i < rijen1; i++) {
            System.out.println("de som van rij " + i + " is " + som[i]);
        }
        for (int j = 0; j < kolommen1; j++) {
            System.out.println("de som van kolom " + j + " is " + som1[j]);
        }

        System.out.println("-----TWEEDE OBJECT------- ");
        System.out.println("geef de rijen en kolommen in ");
        int rijen2 = s.nextInt();
        int kolommen2 = s.nextInt();
        int[][] Array2 = new int[rijen1][kolommen1];

        for (int i = 0; i < rijen1; i++) {
            for (int j = 0; j < kolommen1; j++) {
                Array2[i][j] = (int) (Math.random() * 1000.0 - 500.0);

            }
        }
        Matrix Matrix2 = new Matrix(rijen1, kolommen1);
        System.out.println("Gevulde matrix:  \n");
        Matrix2.afprinten();
        System.out.println("Afgetopte matrix: \n");
        int n = 100;
        Matrix2.aftoppen(n);
        Matrix2.afprinten();
    }
}
