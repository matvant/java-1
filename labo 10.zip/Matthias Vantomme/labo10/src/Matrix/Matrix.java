/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Matrix;

/**
 *
 * @author matthias.vantomme
 */
public class Matrix {

    int rijen;
    int kolommen;
    int[][] matrix;

    public Matrix(int rijen1, int kolommen1) {
        rijen = rijen1;
        kolommen = kolommen1;
        matrix = new int[rijen1][kolommen1];

    }

    public void afprinten() {
        for (int i = 0; i < rijen; i++) {
            for (int j = 0; j < kolommen; j++) {
                System.out.print(matrix[i][j] + "\t");
            }
            System.out.println();
        }

    }

    public int[] rijSommen() {
        int[] som = new int[rijen];
        for (int i = 0; i < rijen; i++) {
            for (int j = 0; j < kolommen; j++) {
                som[i] += matrix[i][j];
            }
        }
        return som;

    }

    public int[] kolomSommen() {
        int[] som = new int[kolommen];
        for (int i = 0; i < rijen; i++) {
            for (int j = 0; j < kolommen; j++) {
                som[i] += matrix[j][i];
            }
        }
        return som;
    }
    public int[][] aftoppen(int n){
        for(int i=0;i<rijen;i++){
            for(int j = 0; j<kolommen;j++){
                if (matrix[i][j] > n){
                    matrix[i][j] = n;
                }
                else if (matrix[i][j] < -n){
                    matrix[i][j] = -n;
                }
            }
        }
   
        
    

